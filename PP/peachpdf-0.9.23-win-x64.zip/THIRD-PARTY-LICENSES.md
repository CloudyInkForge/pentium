# Third-Party Licenses

PeachPDF is BSD 3-Clause-licensed (see [LICENSE](LICENSE)), but it embeds and adapts a small number of third-party components directly in its source tree, each carrying its own license terms. This document collects those licenses, alongside where each component lives in the repo, so they aren't just scattered `LICENSE`/`license.txt` files a reader has to go hunting for.

## PdfSharpCore (embedded fork)

- **Location:** [`src/PeachPDF/PDF/`](src/PeachPDF/PDF/)
- **License file:** [`src/PeachPDF/PDF/LICENSE.md`](src/PeachPDF/PDF/LICENSE.md)
- **License:** MIT

```
## MIT License

Copyright (c) 2001-2024 empira Software GmbH, Troisdorf (Cologne Area), Germany
Copyright (c) 2017-2026 Justin Haygood

http://docs.pdfsharp.net

MIT License

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation
the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.
```

## ExCSS (CSS parser, adapted in-tree)

- **Location:** [`src/PeachPDF/CSS/`](src/PeachPDF/CSS/)
- **License file:** [`src/PeachPDF/CSS/license.txt`](src/PeachPDF/CSS/license.txt)
- **License:** MIT

```
The MIT License (MIT)

Copyright (c) 2024 Tyler Brinks

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

## Bundled font assets

- **Location:** [`assets/fonts/`](assets/fonts/) — shared by the test suite, the showcase harness, and the browser demo; each font's own license notice sits beside it as a `.LICENSE.txt`
- **License:** varies per font (SIL OFL 1.1, 3-Clause BSD, or CC0 for the hand-authored test fixtures)

None of these fonts ships in the PeachPDF library or its NuGet package. See [docs/license.md's "Font assets" table](docs/license.md#font-assets) for the full list, what each one is used for, and its specific license.

## PeachDrawing.Text

Portions of this software are copyright © 1996-2026 The FreeType Project (https://freetype.org). All rights reserved. This software is based in part on the work of the FreeType Team: the TrueType bytecode interpreter and Adobe's CFF engine that grid-fit glyph outlines are ported from FreeType and used under the FreeType Project License (Adobe's files add a patent licence grant, described in the package's notices), whose text ([`FTL.TXT`](src/PeachDrawing.Text/Internal/Hinting/FreeType/FTL.TXT)) ships with the source, in the `PeachDrawing.Text` package and in the `peachpdf` command-line tool's `--credits` output.

The font and text engine lives in its own package, [`PeachDrawing.Text`](src/PeachDrawing.Text/). Its own third-party components (PDFsharp-derived font readers, the ported FreeType interpreter and CFF engine, the ported HarfBuzz algorithms, and the WOFF2 glyph-table reconstruction that follows fontTools) are documented in [`src/PeachDrawing.Text/THIRD-PARTY-LICENSES.md`](src/PeachDrawing.Text/THIRD-PARTY-LICENSES.md); the Unicode Character Database tables, ICU's Thai, Lao, Khmer and Burmese word lists and the hyphenation patterns live in its own dependency, [`PeachDrawing.Text.Data`](src/PeachDrawing.Text.Data/), and are documented in [`src/PeachDrawing.Text.Data/THIRD-PARTY-LICENSES.md`](src/PeachDrawing.Text.Data/THIRD-PARTY-LICENSES.md). Both ship inside their respective packages and are printed after this document by the `peachpdf` command-line tool's `--credits`.

## PeachDrawing

The software rasterizer lives in its own package, [`PeachDrawing`](src/PeachDrawing/). Its `feTurbulence` noise generator ([`Filters/Turbulence.cs`](src/PeachDrawing/Filters/Turbulence.cs)) is a C# transliteration of the reference implementation in the W3C Filter Effects Module Level 1, copyright © 2018 W3C® (MIT, ERCIM, Keio, Beihang), used under the W3C permissive document license; the notice is in [`src/PeachDrawing/THIRD-PARTY-LICENSES.md`](src/PeachDrawing/THIRD-PARTY-LICENSES.md).
